classdef MyClass 
    properties
        % Define properties (data members) here 
        property1
        property2
    end 
    methods 
        % Define methods (functions) here 
        function obj=MyClass(inputArg1,inputArg2)
            % constructor method 
            obj.property1=inputArg1;
            obj.property2=inputArg2;
        end 
        function result = myMethod(obj,inputArg)
            %Example method 
            result = obj.property1+inputArg;
        end 
    end 
end 