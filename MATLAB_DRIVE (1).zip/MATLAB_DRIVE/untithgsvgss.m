% Define the parametric equations for a centroid 
funx=@(t) 2*cos(t).*(1-cos(t));
funy=@(t) 2*sin(t).*(1-cos(t));
% specify the inerval 
tinterval=[0,2*pi];
% plot the centroid 
fplot(funx,funy,tinterval)