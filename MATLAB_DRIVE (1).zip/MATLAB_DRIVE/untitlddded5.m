data= { 'Blue','red','green','red','green'} ;
primary_colors = categorical(data)