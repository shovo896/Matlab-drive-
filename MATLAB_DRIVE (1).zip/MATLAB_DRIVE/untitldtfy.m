%create a figure with some graaphical objects 
fig1=figure('Name','Orginal Figure');
ax1=axes('Parent',fig1);
plot(ax1,rand(10,1));
% copy the figure to a new parent 
fig2=figure('Name','Copied Figure');
newAx=copyobj((ax1,fig2);
% update properties or callbacks as needed
set(newAx,'Color','Yellow');