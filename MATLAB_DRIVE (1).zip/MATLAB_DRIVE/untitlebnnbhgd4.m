h='hell0';
save textdata.out h -ascii 
type textdata.out 