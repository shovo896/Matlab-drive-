x=7*8
y=x*7.89
a=2;b=7;c=a*b
initial_velocity=0;
acceleration=9.8;
time=60
final_velocity=initial_velocity+acceleration*time