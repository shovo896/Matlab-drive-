A=pi*1000*ones(1,5);
sprintf('%f\n %.2f\n %+ .2f\n %12.2f\n %012.2f\n',A)