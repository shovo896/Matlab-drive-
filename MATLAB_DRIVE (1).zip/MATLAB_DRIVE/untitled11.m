x = [ 7.1 , 3.4 , 7.2 , 28/4 , 3.6 ,17 , 9.4 , 8.9 ] ;
length(x) % length of x vector 
y  = rand (3,4 ,5 ,2 ) ; 
ndims (y) % no of dimensions in array y 
s = ['sara', 'Nuha','shamim','Riz','shadab'];
numel(s) % no of el;ements in s 