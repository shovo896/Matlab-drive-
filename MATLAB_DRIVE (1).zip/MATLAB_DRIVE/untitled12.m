a = [ 1 2 3 ; 4 5 6 ; 7 8 9 ]
b = circshift(a ,1)
c = circshift(a , [1 -1])