c = cell ( 2, 5 ); 
c = {'red','blue','yellow','white'; 1  2 3 4 5 } ;