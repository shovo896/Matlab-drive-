y = magic(4)
figure 
plot(y)