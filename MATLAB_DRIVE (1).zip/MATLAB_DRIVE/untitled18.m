x=r*cos(t)
y=r*sin(t)
z=h*t