% Define the moving average filter coefficients 
b=[1/3,1/3, 1/3]; % Numeretor coefficients 
a = 1 ; % Denominator coefficients 
% Generate a noisy signal 
t = 0:0.1: 10 ; 
x= sin(t)+ 0.3*rand(size(t));
%Apply the filter 
y = filter(b,a,x);
% plot the orginal and filtered signals 
subplot(2,1,1);
plot(t,x,'b','Linewidth',2); 
title('orginal noisy signal ');
xlabel('Time');
ylabel('Amplitude');
subplot(2,1,2);
plot(t,y,'r','LineWidth',2) ;
title('Filtered Signal (Moving average');
xlabel('Time');
ylabel('Amplitude');

