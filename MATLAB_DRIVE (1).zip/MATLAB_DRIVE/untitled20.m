% parameters 
r=1 ; %radius 
h=1 ; % pitch 
t = 0:0.1:10*pi; % parameter range 

% parameteric equqtions for x,y,z 
x=r*cos(t);
y=r*sin(t);
z=h*t;

%ploting the helix 
plot3(x,y,z); % ei balchal life spoil korte pare 