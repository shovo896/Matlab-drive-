
a=randi(8,2,3)
a=randi(5,"int32")
a=randi(10,size(p),"like",p)
a=randi([1,5],3 ,3)
a=randperm(n)
a=randperm(n,k)
