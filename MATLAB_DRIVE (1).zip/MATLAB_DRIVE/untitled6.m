a=randperm(10)
a=randperm(10,5)
my_string='Tutorials point'