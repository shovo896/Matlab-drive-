my_string='Tutorial is point ';
str_ascii= unit8(my_string)
str_back_to_char= char(str_ascii)
str_16bit = unit16(my_string)
str_back_to_char = char(str_16bit)
