name = 'Zara Ali        ';
position='sr.surgeo     ';
worksAt='yrerr          ';
profile=char(name,',',position, ',',worksAt);
profile=cellstr(profile)