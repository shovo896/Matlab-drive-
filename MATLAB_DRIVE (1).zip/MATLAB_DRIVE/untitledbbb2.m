A = [ 0 , 0 ,0; 0,1,0 ; 2 , 0 ,0 ; 4 ,0 ,5 ]
sparse_matrix = sparse(A)