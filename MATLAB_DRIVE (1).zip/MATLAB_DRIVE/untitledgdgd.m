% create a simple signal 
x=[1, 2, 3,4];
%calculate the Discrete Fourier transformation (DFT) 0f the signal 
y=fft(x);

% display the orginal signal and its DFT 
disp('Orginal Signal:');
disp(X);
disp('Discrete Fourier Transformation ');
disp(y);