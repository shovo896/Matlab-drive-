% Generate a signal 
t=linspace(0,1,1000);%Time vector 
f=5;%frequency of the signal 
signal=(2*pi*f*t);

% compute the Fourier Transformation 
Y = fft(signal);
% Compute the Inverse Fourier Transformnation with zero padding 
n=2000;
X=ifft(Y,n);

%plot the orginal data and padded signals 
subplot(2,1,1);
plot(t,signal);
title('Orginal Signal')';
xlabel('Time');
ylabel('Amplitude');

subplot(2,1,2);
t_padded=linspace(0,1,n);
plot(t_padded,real(X)) %Display the real part of the signal 
title('Padded Signal');
xlabel('Time');
ylabel('Amplitude');