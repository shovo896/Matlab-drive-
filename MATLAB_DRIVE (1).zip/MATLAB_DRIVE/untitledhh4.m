column_vector =[1; 2 ; 3; 4 ]
row_vector = [5,6,7,8]
result = column_vector + row_vector 
result = column_vector * row_vector 
result = column_vector - row_vector 
data= {'red'}