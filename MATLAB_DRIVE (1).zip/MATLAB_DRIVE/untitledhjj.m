a=[3 2 1 4];
b=[1 -5 6];
k=polyder(a,b);