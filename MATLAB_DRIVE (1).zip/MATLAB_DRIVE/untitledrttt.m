field1 = 'a1' ; value1= zeros(1,10);
field2= 'a2'; value2={'s','b'};
field3 = 'a3'; value3={pi,pi.^2};
field4 = 'a4'; value4={'testing'};
s= struct(field1, value1, field2,value2,field3,value3,field4,value4)
t=rmfield(s,field4)
