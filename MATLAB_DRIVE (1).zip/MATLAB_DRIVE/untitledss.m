n = 20 ;
result = factorial(n)