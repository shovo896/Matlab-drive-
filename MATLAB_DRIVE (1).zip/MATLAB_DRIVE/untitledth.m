% read the image 
img=imread('Screenshot (209).png')

% convert the image to grayscale 
if size(img,3) == 3 
    img_gray=rgb2gray(img);
else
    img_gray=img;
end
% create a Gussian filter 
sigma= 2 ;
hsize=2*ceil(3*sigma)+1; % Filter size
gaussisan_filter=fspecial('gaussian',hsize,sigma);

% create a Laplacian of Gausian flter 
log_filter=fspecial('log',hsize,sigma);
%apply the LoG fiter to the image 

filtered_img=imfilter(double(img_gray),log_filter,'conv','replicate');
% display the orginal and filtered images
subplot(1,2,2);
imshow(unit8(filtered_img));
title('Laplacian of Gaussian Filtered Image');
