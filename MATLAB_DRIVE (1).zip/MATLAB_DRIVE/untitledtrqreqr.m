r^2=2 sin5t
y=rsint
t =linspace(0,2*pi,200);
r=sqrt(abs(2*sin(5*t)));
y=r.*sin(t);
bar(t,y)
axis([0 pi 0 inf]);