x=[0 ,1,0.1];
y=fft(x);
% plotting 
figure;
subplot(2,1,1);
stem(x);
title('Input Signal');
xlabel('time');
ylabel('Amplitude');
subplot(2,1,2);
stem(abs(y));
title('Magnitude of Fourier Transformation');
xlabel('Frequency');
ylabel('Magnitude');