matrix = [ 1, 2 ; 3,4 ; 7,8 ]
column_vector= [10 ; 20 ; 30 ; 40 ]
result= matrix + column_vector 