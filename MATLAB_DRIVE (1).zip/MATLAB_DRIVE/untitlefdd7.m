c{1 ,1}='Hello';
c{1 ,2} = 50 ;
c{1,3}= [1 2 3];
c{2,1}=3.14 ;
c{2,2}= 'Test';
c{2,3}=magic(3) ;
nArr= [1 ,2 ,3 , 4 ,5];
c = num2cell(nArr)