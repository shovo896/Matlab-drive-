try 
    x = 10/0 ;
catch 
    disp (" An error occured : division by zero ");
end 