names={'Riya','tiya','siya'};
ages=[20 , 22 ,19 ] ;
students=struct('Name',names,'Age',ages);
fieldnames(students)
isfield(students,'Names')
a= isstruct(A)