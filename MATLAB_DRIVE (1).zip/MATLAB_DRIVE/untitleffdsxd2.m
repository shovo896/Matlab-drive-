A = [ 3 2 ; 3 3 ; 2  1 ; 3 2 ]
valueset= [1 3 ]; 
catagorynames= { 'poor' 'fair' 'good'}
B = categorical(A,valueset,categorynames,'ordinal',true)