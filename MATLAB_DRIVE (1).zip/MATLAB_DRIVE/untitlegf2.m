xt=@(t) cos(t);
yt=@(t) sin(t);
zt=@(t) t ;

% plot the 3D parametric curve 
fplot3(xt,yt,zt,'LineWidth',2,'Color','b')