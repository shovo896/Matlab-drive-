fs=1000;
t=0:1/fs:1;
f1=50;
x=sin(2*pi*f1*t);
window=hamming(256);
% calculate the spectrum using the specified window 
[s,f,t]=spectrogram(x,window);
imagesc(t,f,10*log(abs(s)));