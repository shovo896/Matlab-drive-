timer=datetime({'2023-1-1 9:40:00';'2023-03-05 9:30:0')};
DayTemp=[25.3;30.3;33.9];
DayPressure=[23.2;23.2;54.6];
T=timetable(timer,DayTemp,DayPressure)