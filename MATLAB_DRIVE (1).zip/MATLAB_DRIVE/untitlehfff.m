syms x
f=1/sqrt(x);
F=laplace(f);
disp(F);