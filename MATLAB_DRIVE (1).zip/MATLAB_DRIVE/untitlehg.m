p=[4 3 2 1];
k=polyder(p)