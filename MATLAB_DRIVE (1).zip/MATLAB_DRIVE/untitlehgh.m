x=[1,2,3,4; 5,6,7,8];
y=fft(x,[],2);
disp('orginal matrix:');
disp(x);
disp('Fourier transformation along columns:');
disp(y)