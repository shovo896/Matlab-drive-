x=[1,2,3,4:4,5,6];
n=4;
y=fft(x,n,2);
disp('Matrix x :');
disp(x);
disp('Fourier Transformation of Each Row(n point DFT):');
disp(y);