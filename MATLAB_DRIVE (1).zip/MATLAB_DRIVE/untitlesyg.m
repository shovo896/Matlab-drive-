syms x 
eq='x^4-7*x^2+3*x^2-5*x+9==ttttt0';
s=solve(eq,x);
disp('The first root is:'),disp(s(1));