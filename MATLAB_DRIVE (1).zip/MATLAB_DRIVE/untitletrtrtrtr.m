vector1=[10, 20 , 30]
vector2= [2,4,6]
result=vector1./ vector2