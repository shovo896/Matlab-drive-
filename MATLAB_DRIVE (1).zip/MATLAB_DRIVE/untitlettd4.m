txt_format=sprintf('Example of left-justify:-%12.2f',11.3)
text_format=sprintf('plus sign:+%5.2f',12.3)
mytxr=sprintf('padding with zeros: %010.2f',5.2)
a ='My age is ';
b=25 



mystr=sprintf('%S %d',a,b)