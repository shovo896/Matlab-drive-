parfor i = 1: 5 
    result(i)= i * 2 ;
end 
disp(result); 