reshaped_A = reshape(A,[],size(A,3))
permuted_A= permute(A,[3,1,2])
squeezed_A=  squeeze(A)