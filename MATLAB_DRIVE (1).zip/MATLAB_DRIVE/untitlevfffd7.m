sum = 0 ;
for i = 1: 5
    sum = sum + i ;
end 
disp(sum) ; 