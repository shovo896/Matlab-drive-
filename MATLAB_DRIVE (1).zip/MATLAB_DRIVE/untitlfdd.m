syms t s 
syms omega real 
f=sin(omega*t);
f_subs=subs(f,t,s/omega); %substitute t with s/omega
F= laplace(f_subs,s);
disp(F);