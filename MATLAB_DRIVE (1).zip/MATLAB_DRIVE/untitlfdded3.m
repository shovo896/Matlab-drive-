scores=[65, 56,83 , 56 , 99,78,100, 67]
edges= [ 0 , 60 , 80 , 100 ]
categories=discretize(scores,edges)