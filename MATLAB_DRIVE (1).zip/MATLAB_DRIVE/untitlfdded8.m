Name= {'riya' ; 'Siya'; 'Tiya '} ;
Age=[25; 30 ; 28] ;
Height= [160 ; 175 ; 168]
Weight= [55 ; 70 ; 65 ] ; 
T = table(Name,Age, Height,Weight);
C = table2cell(T)