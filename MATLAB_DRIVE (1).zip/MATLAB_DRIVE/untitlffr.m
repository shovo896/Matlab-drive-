syms t s a
f= exp(-a*t);
F=laplace(f);
disp(F);