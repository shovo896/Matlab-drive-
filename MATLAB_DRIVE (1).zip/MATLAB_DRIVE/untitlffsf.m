syms t w 
f=exp(-t^2); % DEfine the function 
F=fourier(f);
disp(F)