[X,Y]= meshgrid(1:4,1:4);
V=[5 6 7 8 ; 9 10 11 12 ; 1 14 15 16 ; 1 18 19 20];
[Xq,Yq]=meshgrid(1:0.5:4,1:0.5:4);
% person 2D linear interpolation
Vq=interp2(X,Y,V,Xq,Vq);
%plot the orginal surface 
figure;
surf(X,Y,V);
title('Orginal Surface');
xlabel('X');
ylabel('Y');
zLabel('Value');
%plot the interploted value 
figure;
title('Interploted Surface');
xlabel('Xq');
ylabel('Yq');
zlabel('Interploted Value');