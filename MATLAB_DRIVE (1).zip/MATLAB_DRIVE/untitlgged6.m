N = normalize(X)
N = normalize(X,dim)
N =normalize(X,method)
N=normalize(X,method,methodtype)