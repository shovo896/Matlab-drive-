a = 10;
while ( a<20 )
    fprintf('Value of a:% d\n',a);
    a = a + 1 
end 