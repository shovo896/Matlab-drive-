a = 100 ;
b= 200 ;
switch (a)
    case 100 
        fprintf('This is a part of outer switch %\n',a)
        switch (b)
            case 200 
                fprintf('This is a part of inner switch %\n',a);
        end 
end 
fprintf('Exact value of a is :%d\n',a);
fprintf('Exavct value of b is :%d\n',b);