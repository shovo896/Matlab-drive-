% guass jordan elimination partial pivoting 
for i=1:n
    % pivoting :swap rows if necessary to make the largest absolute value
    % in the 
    % current column the pivot element (for numerical stability)
    [~,pivotRow]=max(abs(A(i:n,i)));
    pivotRow=pivotRow+i-1;
    if pivotRow ~=i 
        A([i,pivotRow],:)=A([pivotRow,i],:);
    end 
    % make the diagonal element 1
    A(i,:)=A(i,:)/A(i,i);
    %Make the other elements in the current column 0 
    for l = 1:n 
        if i~=j 
            A(j,:)=A(j,:)-A(j,i)*A(i,:);
        end 
    end 
end 