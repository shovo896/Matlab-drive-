Name={'Siya';'Riya';'Hwelen';'Reena'};
Age=[25;30;36;40];
Height=[149;150;160;153];
weight=[50;45;45;52]
Timer=datetime({'2023-01-01 09:00:00';'2023-01-01 09:30:00' 
    '2023-01-01 10:00:00';'2023-01-01 11:00:00'})
T=table(Name,Age,Height,Weight,Timer)