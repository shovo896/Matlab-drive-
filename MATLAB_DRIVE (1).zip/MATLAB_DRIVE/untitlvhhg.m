syms x 
limit((x^3+5)/(x^4+7),1)