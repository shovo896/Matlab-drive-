syms t s 
f= exp(-2*t)*cos((3*t);
F=laplace(f,t,s/2);
disp(F);