% Define the augmented matrix 
A=[1 2 3 4 9 ; 2 3 4 5 6; 3 4 5 1 7];
% Get the number of rows 
n=size(A,1);
for i = 1:n 
    % pivoting : swap rows if necessary to make the largest absolute value
    % in the  current column the pivot element 
    % [~,pivotRow]=max(abs(A(i:n,i)));
    pivotRow=pivotRow+i-1;
    if pivotRow~=i
        A([i,pivotRow],:)=A([pivotRow,i],:);
    end 
    % make diagonal element 1
     A(i,:)=A(i,:)/A(i,i);
     for j=1:n 
         if i~=j 
             A(j,:)=A(j,:)-A(j,i)*A(i,:);
         end 
     end 
end 
%Extract the solution 
solution=A(:,end);
% display the result 
disp('The solution is:');
disp(solution)