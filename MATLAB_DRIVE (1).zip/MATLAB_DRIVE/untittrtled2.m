matrix1= [1 2 ; 3 4 ]
matrix2= [5 6 ; 7 8]
result =matrix1 + matrix2
scalar = 5 
result = matrix + scalar 