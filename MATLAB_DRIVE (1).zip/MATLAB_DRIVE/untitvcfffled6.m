grade = 'B';
    switch(grade)
        case 'A'
            fprintf('Excellent\n');
        case 'B'
            fprintf('well done ');
        case 'c'
            fprintf('Well done\n');
        case 'D'
            fprintf('You passed\n');
        case 'f'
            fprintf('Better try again ');
        otherwise 
            fprintf('Invaid grade \n');
    end 
            