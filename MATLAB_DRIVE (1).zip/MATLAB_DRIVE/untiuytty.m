data_matrix= [10,20,30,40;50,60,70,80];
average_value=mean(data_matrix,'all')