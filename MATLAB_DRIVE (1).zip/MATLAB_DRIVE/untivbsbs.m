x=imread('462543001_8615943498521709_7890765814037169411_n.jpg');
figure 
imshow(x);
title('Input Image');
figure;
h=fspecial('laplacian');
filtered_image=imfilter(x,h);
imshow(filtered_image);
title('Output of Laplacian Filter');
figure;
h=fspecial('log');
filtered_image=imfilter(x,h);
imshow(filtered_image);
title('Laplacian Gaussian Filter');