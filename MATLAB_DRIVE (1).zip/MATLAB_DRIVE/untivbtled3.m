num_array=[1  2  3 4 ; 4 5 5 6 ; 7 8 9 0];
save array_data1.out num_array -ascii ;
type array_data1.out
dlmwrite('array_data2.out',num_array,'');
type array_data2.out 