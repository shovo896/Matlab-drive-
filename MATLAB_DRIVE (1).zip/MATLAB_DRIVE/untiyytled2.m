a=rand
a=rand(n)
a=rand(sz1 , sz2,.........szn )
a=rand(sz)
a=rand(_, typename)
a=rand(_,"like",p)
a=rand(s,_)