Names = { 'siua'; 'Riya'; 'Jiya'; 'tiysa'; 'kiya'}; 
Age= [45 ; 33; 27 ; 20 ; 48 ] ; 
Height = [105 ; 140 ; 150 ; 130 ; 156 ] ;
Weight = [60 ; 80 ; 50 ; 45 ; 54 ] ; 
T = table(Age, weight,Height.'RowNames',Names)