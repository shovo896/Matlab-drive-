a = 9 ;
while a < 20 
    a = a+1 ;
    if a == 15 
        continue ;
    end 
fprintf('value of a : % d\n',a);
end 
