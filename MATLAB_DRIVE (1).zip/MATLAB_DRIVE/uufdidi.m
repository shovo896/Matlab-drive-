syms x 
solve((x-3)^2 * (x-7) == 0,x)